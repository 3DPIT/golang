package custompkg

import "fmt"

func PrintCustom() {
	fmt.Println("This is custom package!")
}
