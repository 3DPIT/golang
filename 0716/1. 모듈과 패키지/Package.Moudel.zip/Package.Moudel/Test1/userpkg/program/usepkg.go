package main

import (
	"0716/Test1/userpkg/custompkg"
	"fmt"

	"github.com/guptarohit/asciigraph"
	"github.com/tuckersGo/musthaveGo/ch16/expkg"
)

func main() {
	custompkg.PrintCustom()
	expkg.PrintSample()
	data := []float64{1, 2, 3, 4, 5, 4, 3, 4, 4, 4, 3, 3, 4, 3}
	graph := asciigraph.Plot(data)
	fmt.Println(graph)
}
