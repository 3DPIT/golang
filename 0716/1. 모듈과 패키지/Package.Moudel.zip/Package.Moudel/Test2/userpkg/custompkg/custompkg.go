package custompkg

import "fmt"

func PrintCustom() {
	fmt.Println("This is custom package!")
}
func printCuston2() {
	fmt.Println("This is custom package2!")
}
