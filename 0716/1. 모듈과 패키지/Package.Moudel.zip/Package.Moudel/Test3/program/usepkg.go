package main

import (
	"0716/Test1/userpkg/custompkg"
	"0716/Test3/exinit"
)

func main() {
	custompkg.PrintCustom()
	exinit.PrintD()
}
