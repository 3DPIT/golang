package ICalender

type ICalender interface {
	ChangeCalender(int) string
}
