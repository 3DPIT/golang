package main

import (
	"fileMonitoring/Mirero.Go.InterfaceMock/ICalender"
	"fmt"
	"strconv"
)

var DateStringData = [6]string{"년", "월", "일", "시", "분", "초"}

type Calender struct {
	ICalender ICalender.ICalender
}

func (c *Calender) ChangeCalender(number int) string {
	// 리펙토링한 숫자 20211105124040를 2021년11월05일12시40분40초로 바꿔주는 함수
	ChangeStirngNumber := strconv.Itoa(number)
	checkWord := 3
	stringChkIdx := 3
	day := make([]string, 0)
	for i := 0; i < len(ChangeStirngNumber); i++ {
		day = append(day, ChangeStirngNumber[i:i+1])
		if i == checkWord {
			day = append(day, DateStringData[i-stringChkIdx])
			checkWord += 2
			stringChkIdx++
		}
	}
	days := ""
	for _, data := range day {
		days += data
	}
	c.ICalender.ChangeCalender(number)
	return days
}

func main() {
	calender := Calender{}
	s := calender.ChangeCalender(20111205081756)
	fmt.Println(s)
}
