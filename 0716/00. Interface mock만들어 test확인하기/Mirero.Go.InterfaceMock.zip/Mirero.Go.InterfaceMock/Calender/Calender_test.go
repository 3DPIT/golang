package Calender_test

import (
	"fileMonitoring/Mirero.Go.InterfaceMock/Calender"
	"fileMonitoring/Mirero.Go.InterfaceMock/mocks"
	"testing"

	"github.com/golang/mock/gomock"
	"github.com/stretchr/testify/assert"
)

func TestChangeCalender(t *testing.T) {
	assert := assert.New(t)
	mockCtrl := gomock.NewController(t)
	defer mockCtrl.Finish()
	mockCalender := mocks.NewMockICalender(mockCtrl)
	mockCalender.EXPECT().ChangeCalender(20111105081756).Return("2011년11월05일08시17분56초").Times(1)
	testCalender := &Calender.Calender1{ICalender: mockCalender}
	s := testCalender.ChangeCalender(20111105081756)
	assert.Equal("2011년11월05일08시17분56초", s)
}
